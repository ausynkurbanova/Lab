<?php

interface VehiclePrototype {
    public function clone();
    public function info();
}
class Car implements VehiclePrototype {
    public $brand;
    public $color;

    public function __construct($brand, $color) {
        $this->brand = $brand;
        $this->color = $color;
    }

    public function clone() {
        return clone $this;
    }

    public function info() {
        return "Легковий автомобіль: {$this->brand}, колір: {$this->color}";
    }
}

class Truck implements VehiclePrototype {
    public $brand;
    public $capacity;

    public function __construct($brand, $capacity) {
        $this->brand = $brand;
        $this->capacity = $capacity;
    }

    public function clone() {
        return clone $this;
    }

    public function info() {
        return "Вантажівка: {$this->brand}, вантажність: {$this->capacity} т";
    }
}

class Bus implements VehiclePrototype {
    public $brand;
    public $seats;

    public function __construct($brand, $seats) {
        $this->brand = $brand;
        $this->seats = $seats;
    }

    public function clone() {
        return clone $this;
    }

    public function info() {
        return "Автобус: {$this->brand}, місць: {$this->seats}";
    }
}

function buildPark($carNum, $truckNum, $busNum, $carProto, $truckProto, $busProto) {
    $park = [];

    for ($i = 0; $i < $carNum; $i++) {
        $park[] = $carProto->clone();
    }

    for ($i = 0; $i < $truckNum; $i++) {
        $park[] = $truckProto->clone();
    }

    for ($i = 0; $i < $busNum; $i++) {
        $park[] = $busProto->clone();
    }

    return $park;
}

$carPrototype   = new Car("Toyota", "Black");
$truckPrototype = new Truck("Volvo", 12);
$busPrototype   = new Bus("Mercedes", 45);

$carNum   = 10;
$truckNum = 3;
$busNum   = 5;

$park = buildPark($carNum, $truckNum, $busNum, $carPrototype, $truckPrototype, $busPrototype);

echo "Парк автомобілів:\n\n";

foreach ($park as $vehicle) {
    echo $vehicle->info() . "\n";
}

?>
