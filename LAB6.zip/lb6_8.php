<?php

class TwitterService
{
    protected $_data = [];

    public function setMessage($text)
    {
        $this->_data['message'] = $text;
        echo "Twitter message: " . $this->_data['message'] . PHP_EOL;
    }

    public function sendTweet() {
        echo "Tweet sent!" . PHP_EOL;
    }
}


class SmsService
{
    protected $recipient;
    protected $message;
    protected $sendTime; // нове поле

    public function setRecipient($recipient)
    {
        $this->recipient = $recipient;
    }

    public function setMessage($message)
    {
        $this->message = $message;
    }

    public function setTime($time)
    {
        $this->sendTime = $time;
    }

    public function sendText()
    {
        echo "SMS to: {$this->recipient}" . PHP_EOL;
        echo "Message: {$this->message}" . PHP_EOL;
        echo "Send time: " . ($this->sendTime ?? "now") . PHP_EOL;
        echo "SMS sent!" . PHP_EOL;
    }
}

interface NotificationInterface {
    public function setData($data);
    public function sendNotification();
}

class TwitterAdapter implements NotificationInterface
{
    protected $_data;

    public function setData($data){
        $this->_data = $data;
    }

    public function sendNotification()
    {
        $twitter = new TwitterService();
        $twitter->setMessage($this->_data['message']);
        $twitter->sendTweet();
    }
}

class SmsAdapter implements NotificationInterface
{
    protected $_data;

    public function setData($data){
        $this->_data = $data;
    }

    public function sendNotification()
    {
        $sms = new SmsService();
        $sms->setRecipient($this->_data['recipient']);
        $sms->setMessage($this->_data['message']);

        if(isset($this->_data['time'])){
            $sms->setTime($this->_data['time']);
        }

        $sms->sendText();
    }
}

interface INotificationManager {
    public function sendNotification($type = '', $data);
}

class NotificationManager implements INotificationManager
{
    public function sendNotification($type = '', $data)
    {
        switch($type){
            case "twitter":
                $notification = new TwitterAdapter();
                break;

            case "sms":
                $notification = new SmsAdapter();
                break;

            default:
                echo "Error: unknown notification type" . PHP_EOL;
                return false;
        }

        $notification->setData($data);
        $notification->sendNotification();
    }
}


echo "=== TWITTER ===" . PHP_EOL;
$twitterData = [
    "message" => "This is tweet"
];

$manager = new NotificationManager();
$manager->sendNotification("twitter", $twitterData);

echo PHP_EOL . "=== SMS ===" . PHP_EOL;

$smsData = [
    "recipient" => "+380671234567",
    "message" => "Your verification code: 1234",
    "time" => "2025-11-25 15:30"
];

$manager->sendNotification("sms", $smsData);

?>
