<?php

class Client {
    public $name;
    public $address;
    public $accountNumber;

    public function __construct($name = "", $address = "", $accountNumber = "") {
        $this->name = $name;
        $this->address = $address;
        $this->accountNumber = $accountNumber;
    }

    public function get() {
        return [
            'name' => $this->name,
            'address' => $this->address,
            'accountNumber' => $this->accountNumber
        ];
    }

    public function show() {
        echo "Ім'я: $this->name\n";
        echo "Адреса: $this->address\n";
        echo "Рахунок: $this->accountNumber\n";
        echo "----------------------\n";
    }
}

class SmsService {
    public function setRecipient($recipient) {
        $this->recipient = $recipient;
    }

    public function setMessage($message) {
        $this->message = $message;
    }

    public function sendText() {
        echo "SMS to: {$this->recipient}\n";
        echo "Message: {$this->message}\n";
        echo "SMS sent!\n";
    }
}

interface NotificationInterface {
    public function setData($data);
    public function sendNotification();
}

class SmsAdapter implements NotificationInterface {
    protected $_data;

    public function setData($data){
        $this->_data = $data;
    }

    public function sendNotification() {
        $sms = new SmsService();
        $sms->setRecipient($this->_data['recipient']);
        $sms->setMessage($this->_data['message']);
        $sms->sendText();
    }
}

class NotificationManager {
    public function sendNotification($type, $data) {
        switch($type){
            case "sms":
                $notification = new SmsAdapter();
                break;
            default:
                echo "Error: unknown notification type\n";
                return false;
        }

        $notification->setData($data);
        $notification->sendNotification();
    }
}


$client1 = new Client("Sofia", "Kyiv, Ukraine", "43893412");
$client1->show();

$manager = new NotificationManager();
$manager->sendNotification("sms", [
    'recipient' => '+380671234567',
    'message' => "Hello {$client1->name}, your account number is {$client1->accountNumber}"
]);

?>
