<?php

interface Prototype {
    public function clone();
}

class Client implements Prototype {
    public $name;
    public $address;
    public $accountNumber;

    public function __construct($name = "", $address = "", $accountNumber = "") {
        $this->name = $name;
        $this->address = $address;
        $this->accountNumber = $accountNumber;
    }

    public function set($name, $address, $accountNumber) {
        $this->name = $name;
        $this->address = $address;
        $this->accountNumber = $accountNumber;
    }

    public function get() {
        return [
            'name' => $this->name,
            'address' => $this->address,
            'accountNumber' => $this->accountNumber
        ];
    }

    public function show() {
        echo "Ім'я: $this->name\n";
        echo "Адреса: $this->address\n";
        echo "Рахунок: $this->accountNumber\n";
        echo "----------------------\n";
    }

    public function search($keyword) {
        return ($this->name === $keyword || $this->accountNumber === $keyword);
    }

    public static function showAll($clients) {
        foreach ($clients as $client) {
            $client->show();
        }
    }

    // Prototype
    public function clone() {
        return clone $this;
    }
}

$client1 = new Client("Sofia", "Kyiv, Ukraine", "43893412");
$client2 = new Client("Ivan", "Odesa, Ukraine", "56894574");
$client3 = new Client("Mila", "Lviv, Ukraine", "46907256");

// -----------------------------
$client4 = $client1->clone();
$client4->set("Andrii", "Dnipro, Ukraine", "56903476");

$client5 = $client2->clone();
$client5->set("Katya", "Sumy, Ukraine", "53177523");

$clients = [$client1, $client2, $client3, $client4, $client5];

Client::showAll($clients);
$searchKey = "Mila";
if ($client3->search($searchKey)) {
    echo "Знайдено клієнта з ім'ям: $searchKey\n";
}

?>
