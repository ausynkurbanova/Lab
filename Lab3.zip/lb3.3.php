<?php

abstract class ClientBase {
    protected $name;
    protected $address;
    protected $accountNumber;

    public function __construct($name, $address, $accountNumber) {
        $this->name = $name;
        $this->address = $address;
        $this->accountNumber = $accountNumber;
    }

    // Абстрактний метод
    abstract public function showInfo();

    // Загальний метод
    public function getAccount() {
        return $this->accountNumber;
    }
}

class Client extends ClientBase {

    public function showInfo() {
        echo "Client: $this->name, Address: $this->address, Account: $this->accountNumber\n";
    }
}

class VipClient extends ClientBase {
    private $discount = 10;

    public function showInfo() {
        echo "VIP Client: $this->name, Address: $this->address, Account: $this->accountNumber, Discount: $this->discount%\n";
    }
}

$c = new Client("Aisun", "Sumy, Ukraine", "00012345");
$c->showInfo();

$vip = new VipClient("Anna", "Kyiv, Ukraine", "12399999");
$vip->showInfo();

?>
