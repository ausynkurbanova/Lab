<?php
interface Loggable {
    public function log($message);
}

interface Printable {
    public function printInfo();
}
class A {

    public static function test() {
        echo "Method test() from class A\n";
    }

    public static function get() {

        self::test();
    }
}


class B extends A {

    public static function test() {
        echo "Method test() from class B\n";
    }
}

class MultiClass implements Loggable, Printable {

    private $data;

    public function __construct($data) {
        $this->data = $data;
    }

    public function log($message) {
        echo "[LOG]: $message\n";
    }

    public function printInfo() {
        echo "Stored data: {$this->data}\n";
    }
}

echo "Calling B::get():\n";
B::get();

echo "\n";

$obj = new MultiClass("Example data");

$obj->log("Test logging...");
$obj->printInfo();

?>
