<?php

interface Figure {
    public function draw();
    public function erase();
    public function move($x, $y);
    public function getColor();
    public function setColor($color);
}


class BaseFigure implements Figure {
    protected $color = "black";
    protected $x = 0;
    protected $y = 0;

    public function draw() {}
    public function erase() {}

    public function move($x, $y) {
        $this->x = $x;
        $this->y = $y;
        echo "Moved to position ($this->x, $this->y)\n";
    }

    public function getColor() {
        return $this->color;
    }

    public function setColor($color) {
        $this->color = $color;
        echo "Color set to: $this->color\n";
    }
}


class Circle extends BaseFigure {
    public function draw() {
        echo "Drawing Circle, color: " . $this->color . "\n";
    }

    public function erase() {
        echo "Erasing Circle\n";
    }
}

class Square extends BaseFigure {
    public function draw() {
        echo "Drawing Square, color: " . $this->color . "\n";
    }

    public function erase() {
        echo "Erasing Square\n";
    }
}


class Triangle extends BaseFigure {
    public function draw() {
        echo "Drawing Triangle, color: " . $this->color . "\n";
    }

    public function erase() {
        echo "Erasing Triangle\n";
    }
}


$circle = new Circle();
$circle->setColor("red");
$circle->draw();
$circle->move(10, 20);
$circle->erase();

echo "\n";

$square = new Square();
$square->setColor("blue");
$square->draw();
$square->erase();

echo "\n";

$triangle = new Triangle();
$triangle->setColor("green");
$triangle->draw();
$triangle->erase();

?>
