<?php

class Client {
    public $name;
    public $address;
    public $accountNumber;

    public function __construct($name = "", $address = "", $accountNumber = "") {
        $this->name = $name;
        $this->address = $address;
        $this->accountNumber = $accountNumber;
    }

    public function set($name, $address, $accountNumber) {
        $this->name = $name;
        $this->address = $address;
        $this->accountNumber = $accountNumber;
    }

    public function get() {
        return [
            'name' => $this->name,
            'address' => $this->address,
            'accountNumber' => $this->accountNumber
        ];
    }

    public function show() {
        echo "Ім'я: $this->name\n";
        echo "Адреса: $this->address\n";
        echo "Рахунок: $this->accountNumber\n";
        echo "----------------------\n";
    }

    public function search($keyword) {
        return ($this->name === $keyword || $this->accountNumber === $keyword);
    }

    public static function showAll($clients) {
        foreach ($clients as $client) {
            $client->show();
        }
    }
}

class ClientFactory {
    public static function create($name, $address, $accountNumber) {
        return new Client($name, $address, $accountNumber);
    }
}

$client1 = ClientFactory::create("Sofia", "Kyiv, Ukraine", "43893412");
$client2 = ClientFactory::create("Ivan", "Odesa, Ukraine", "56894574");
$client3 = ClientFactory::create("Mila", "Lviv, Ukraine", "46907256");
$client4 = ClientFactory::create("Andrii", "Dnipro, Ukraine", "56903476");
$client5 = ClientFactory::create("Katya", "Sumy, Ukraine", "53177523");

$clients = [$client1, $client2, $client3, $client4, $client5];

Client::showAll($clients);

$searchKey = "Mila";
if ($client3->search($searchKey)) {
    echo "Знайдено клієнта з ім’ям: $searchKey\n";
}

?>
