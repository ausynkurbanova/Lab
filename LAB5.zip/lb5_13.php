<?php

trait ClientMethods {
    public function set($name, $address, $accountNumber) {
        $this->name = $name;
        $this->address = $address;
        $this->accountNumber = $accountNumber;
    }

    public function get() {
        return [
            'name' => $this->name,
            'address' => $this->address,
            'accountNumber' => $this->accountNumber
        ];
    }

    public function show() {
        echo "Ім'я: {$this->name}\n";
        echo "Адреса: {$this->address}\n";
        echo "Рахунок: {$this->accountNumber}\n";
        echo "----------------------\n";
    }

    public function search($keyword) {
        return ($this->name === $keyword || $this->accountNumber === $keyword);
    }

    public static function showAll($clients) {
        foreach ($clients as $client) {
            $client->show();
        }
    }
}

interface ClientProduct {
    public function getName();
}

class Client implements ClientProduct {
    use ClientMethods;

    public $name;
    public $address;
    public $accountNumber;

    public function __construct($name = "", $address = "", $accountNumber = "") {
        $this->name = $name;
        $this->address = $address;
        $this->accountNumber = $accountNumber;
    }

    public function getName() {
        return $this->name;
    }
}

interface ClientFactory {
    public function createClient($name, $address, $accountNumber): ClientProduct;
}

class DefaultClientFactory implements ClientFactory {
    public function createClient($name, $address, $accountNumber): ClientProduct {
        return new Client($name, $address, $accountNumber);
    }
}

class VIPClientFactory implements ClientFactory {
    public function createClient($name, $address, $accountNumber): ClientProduct {
        $client = new Client($name, $address, $accountNumber);
        return $client;
    }
}

$factory = new DefaultClientFactory();

$client1 = $factory->createClient("Sofia", "Kyiv, Ukraine", "43893412");
$client2 = $factory->createClient("Ivan", "Odesa, Ukraine", "56894574");
$client3 = $factory->createClient("Mila", "Lviv, Ukraine", "46907256");
$client4 = $factory->createClient("Andrii", "Dnipro, Ukraine", "56903476");
$client5 = $factory->createClient("Katya", "Sumy, Ukraine", "53177523");

$clients = [$client1, $client2, $client3, $client4, $client5];

Client::showAll($clients);

$searchKey = "Mila";
if ($client3->search($searchKey)) {
    echo "Знайдено клієнта з ім’ям: $searchKey\n";
}

?>
