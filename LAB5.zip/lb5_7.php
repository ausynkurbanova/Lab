<?php

class Vehicle {
    public $country;
    public $brand;
    public $year;

    public function __construct($country, $brand, $year) {
        $this->country = $country;
        $this->brand = $brand;
        $this->year = $year;
    }

    public function show() {
        echo "Країна: $this->country\n";
        echo "Марка: $this->brand\n";
        echo "Рік: $this->year\n";
    }
}

class Car extends Vehicle {
    public $engine;
    public $power;
    public $color;

    public function __construct($country, $brand, $year, $engine, $power, $color) {
        parent::__construct($country, $brand, $year);
        $this->engine = $engine;
        $this->power = $power;
        $this->color = $color;
    }

    public function show() {
        parent::show();
        echo "Двигун: $this->engine\n";
        echo "Потужність: $this->power\n";
        echo "Колір: $this->color\n";
        echo "--------------------\n";
    }
}

class Bike extends Vehicle {
    public $weight;
    public $type;
    public $wheelDiameter;

    public function __construct($country, $brand, $year, $weight, $type, $wheelDiameter) {
        parent::__construct($country, $brand, $year);
        $this->weight = $weight;
        $this->type = $type;
        $this->wheelDiameter = $wheelDiameter;
    }

    public function show() {
        parent::show();
        echo "Вага: $this->weight kg\n";
        echo "Тип: $this->type\n";
        echo "Діаметр колеса: $this->wheelDiameter\"\n";
        echo "--------------------\n";
    }
}

class Motorcycle extends Vehicle {
    public $engine;
    public $color;
    public $type;

    public function __construct($country, $brand, $year, $engine, $color, $type) {
        parent::__construct($country, $brand, $year);
        $this->engine = $engine;
        $this->color = $color;
        $this->type = $type;
    }

    public function show() {
        parent::show();
        echo "Двигун: $this->engine\n";
        echo "Колір: $this->color\n";
        echo "Тип: $this->type\n";
        echo "--------------------\n";
    }
}
class VehicleFactory {

    public static function create($type, ...$params) {

        switch (strtolower($type)) {
            case "car":
                return new Car(...$params);

            case "bike":
                return new Bike(...$params);

            case "motorcycle":
                return new Motorcycle(...$params);

            default:
                echo "Фабрика не може створити транспортний засіб типу: $type\n";
                return null;
        }
    }
}
$car = VehicleFactory::create(
    "car",
    "Germany", "BMW", 2020,
    "3.0L", "250hp", "Black"
);
$car->show();
$bike = VehicleFactory::create(
    "bike",
    "Italy", "Bianchi", 2019,
    12, "mountain", 29
);
$bike->show();
$moto = VehicleFactory::create(
    "motorcycle",
    "Japan", "Honda", 2021,
    "600cc", "Red", "sport"
);
$moto->show();
$plane = VehicleFactory::create("plane");

?>
