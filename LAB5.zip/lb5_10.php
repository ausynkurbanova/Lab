<?php

interface ClientProduct {
    public function getName();
    public function getData();
    public function show();
}

class Client implements ClientProduct {

    public $name;
    public $address;
    public $accountNumber;

    public function __construct($name, $address, $accountNumber) {
        $this->name = $name;
        $this->address = $address;
        $this->accountNumber = $accountNumber;
    }

    public function getName() {
        return $this->name;
    }

    public function getData() {
        return [
            'name' => $this->name,
            'address' => $this->address,
            'accountNumber' => $this->accountNumber
        ];
    }

    public function show() {
        echo "Ім'я: {$this->name}\n";
        echo "Адреса: {$this->address}\n";
        echo "Рахунок: {$this->accountNumber}\n";
        echo "------------------------\n";
    }
}

interface ClientFactory {
    public function getClient($name, $address, $accountNumber): ClientProduct;
}

class DefaultClientFactory implements ClientFactory {
    public function getClient($name, $address, $accountNumber): ClientProduct {
        return new Client($name, $address, $accountNumber);
    }
}


$factory = new DefaultClientFactory();

$client1 = $factory->getClient("Sofia", "Kyiv, Ukraine", "43893412");
$client2 = $factory->getClient("Ivan", "Odesa, Ukraine", "56894574");
$client3 = $factory->getClient("Mila", "Lviv, Ukraine", "46907256");
$client4 = $factory->getClient("Andrii", "Dnipro, Ukraine", "56903476");
$client5 = $factory->getClient("Katya", "Sumy, Ukraine", "53177523");

$clients = [$client1, $client2, $client3, $client4, $client5];

foreach ($clients as $c) {
    $c->show();
}

$searchKey = "Mila";
if ($client3->getName() === $searchKey) {
    echo "Знайдено клієнта з ім'ям: $searchKey\n";
}

?>
