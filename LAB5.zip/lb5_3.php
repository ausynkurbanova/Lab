<?php

trait Singleton
{
    private static $instance = null;

    private function __clone() {}

    public function __wakeup()
    {
        throw new Exception("Cannot unserialize Singleton");
    }

    public static function getInstance()
    {
        if (static::$instance === null) {
            static::$instance = new static();
        }
        return static::$instance;
    }
}


class db
{
    use Singleton;

    public $db;

    private function __construct()
    {
        echo "Connecting with database...\n";

        $password = "";

        $this->db = new mysqli('localhost', 'root', $password);

        if ($this->db->connect_error) {
            throw new Exception("Connection error: " . $this->db->connect_error);
        }

        $this->db->query("SET NAMES 'UTF8'");
    }

    public function get_data()
    {
        $query = "SELECT * FROM menu";
        $result = $this->db->query($query);

        $rows = [];
        while ($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }
        return $rows;
    }
}
-

try {
    $obj1 = db::getInstance();
    $obj2 = db::getInstance();
    $obj3 = db::getInstance();

    var_dump($obj1 === $obj2);
    var_dump($obj2 === $obj3);

} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}

?>
