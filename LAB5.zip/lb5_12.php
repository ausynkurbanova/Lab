<?php

interface Car {
    public function getInfo();
}

interface Truck {
    public function getInfo();
}

interface Bus {
    public function getInfo();
}

class UACar implements Car {
    public function getInfo() {
        return "Легковий автомобіль (Виробництво: Україна)";
    }
}

class UATruck implements Truck {
    public function getInfo() {
        return "Вантажівка (Виробництво: Україна)";
    }
}

class UABus implements Bus {
    public function getInfo() {
        return "Автобус (Виробництво: Україна)";
    }
}

class ForeignCar implements Car {
    public function getInfo() {
        return "Легковий автомобіль (Виробництво: Зарубіжне)";
    }
}

class ForeignTruck implements Truck {
    public function getInfo() {
        return "Вантажівка (Виробництво: Зарубіжне)";
    }
}

class ForeignBus implements Bus {
    public function getInfo() {
        return "Автобус (Виробництво: Зарубіжне)";
    }
}

interface VehicleFactory {
    public function createCar(): Car;
    public function createTruck(): Truck;
    public function createBus(): Bus;
}

class UAFactory implements VehicleFactory {
    public function createCar(): Car {
        return new UACar();
    }
    public function createTruck(): Truck {
        return new UATruck();
    }
    public function createBus(): Bus {
        return new UABus();
    }
}

class ForeignFactory implements VehicleFactory {
    public function createCar(): Car {
        return new ForeignCar();
    }
    public function createTruck(): Truck {
        return new ForeignTruck();
    }
    public function createBus(): Bus {
        return new ForeignBus();
    }
}

class VehiclePark {
    public $cars = [];
    public $trucks = [];
    public $buses = [];

    public function __construct(VehicleFactory $factory, $carNum, $truckNum, $busNum) {
        for ($i = 0; $i < $carNum; $i++) {
            $this->cars[] = $factory->createCar();
        }
        for ($i = 0; $i < $truckNum; $i++) {
            $this->trucks[] = $factory->createTruck();
        }
        for ($i = 0; $i < $busNum; $i++) {
            $this->buses[] = $factory->createBus();
        }
    }

    public function showPark() {
        echo "Легкові автомобілі:\n";
        foreach ($this->cars as $car) {
            echo "- " . $car->getInfo() . "\n";
        }
        echo "\nВантажівки:\n";
        foreach ($this->trucks as $truck) {
            echo "- " . $truck->getInfo() . "\n";
        }
        echo "\nАвтобуси:\n";
        foreach ($this->buses as $bus) {
            echo "- " . $bus->getInfo() . "\n";
        }
    }
}

$config = parse_ini_file("config.ini"); // Створіть файл config.ini

$factoryType = $config['factory'] ?? 'ua';
$carNum = intval($config['carNum'] ?? 0);
$truckNum = intval($config['truckNum'] ?? 0);
$busNum = intval($config['busNum'] ?? 0);

$factory = ($factoryType === 'ua') ? new UAFactory() : new ForeignFactory();

$park = new VehiclePark($factory, $carNum, $truckNum, $busNum);
$park->showPark();

?>
