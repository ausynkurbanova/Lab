<?php

trait my_first_trait
{
    public function traitFunction()
    {
        echo "Hello world\n";
    }

    public function greetByTime()
    {
        $hour = date("H");

        if ($hour >= 5 && $hour < 12) {
            echo "Good morning";
        } elseif ($hour >= 12 && $hour < 18) {
            echo "Good day";
        } elseif ($hour >= 18 && $hour < 23) {
            echo "Good evening";
        } else {
            echo "Good night";
        }
    }
}

class helloWorld
{
    use my_first_trait;
}

$objTest = new HelloWorld();

$objTest->traitFunction();
$objTest->greetByTime();

?>
