<?php

trait NameTrait {
    private string $name;

    public function setName(string $name): void {
        $this->name = $name;
    }

    public function getName(): string {
        return $this->name;
    }
}

trait AddressTrait {
    private string $address;

    public function setAddress(string $address): void {
        $this->address = $address;
    }

    public function getAddress(): string {
        return $this->address;
    }
}

trait AccountNumberTrait {
    private string $accountNumber;

    public function setAccountNumber(string $accountNumber): void {
        $this->accountNumber = $accountNumber;
    }

    public function getAccountNumber(): string {
        return $this->accountNumber;
    }
}

class Client {
    use NameTrait, AddressTrait, AccountNumberTrait;

    public function printClientInfo(): void {
        echo "Client Info:\n";
        echo "Name: " . $this->getName() . "\n";
        echo "Address: " . $this->getAddress() . "\n";
        echo "Account Number: " . $this->getAccountNumber() . "\n";
    }
}

$client = new Client();
$client->setName("Aisun Kurbanova");
$client->setAddress("1 Street, Sumy");
$client->setAccountNumber("1234567890");

$client->printClientInfo();
?>
