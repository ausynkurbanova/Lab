<?php

interface ILogger {
    public function log(string $message): void;
}

trait DateTimeTrait {
    public function getCurrentDateTime(): string {
        return date('F d, Y, g:i a'); // Формат: October 10, 2022, 7:43 pm
    }
}

trait FileWriteTrait {
    private string $filePath = 'log.txt';

    public function writeToFile(string $message): void {
        file_put_contents($this->filePath, $message . "\n", FILE_APPEND);
    }
}

class FileLogger implements ILogger {
    use DateTimeTrait;
    use FileWriteTrait;

    public function log(string $message): void {
        $dateTime = $this->getCurrentDateTime();
        $logMessage = "$dateTime: $message";
        $this->writeToFile($logMessage);
        echo "Logged: $logMessage\n";
    }
}

$logger = new FileLogger();

$logger->log("log message");
$logger->log("another log message");

?>
