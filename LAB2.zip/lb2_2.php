<?php

class Point {
    protected $x;
    protected $y;

    public function __construct($x = 0, $y = 0) {
        $this->x = $x;
        $this->y = $y;
        echo "Point created: ($this->x, $this->y)\n";
    }

    public function __destruct() {
        echo "Point destroyed: ($this->x, $this->y)\n";
    }

    public function printInfo() {
        echo "Point: ($this->x, $this->y)\n";
    }
}

class ColorPoint extends Point {
    protected $color;

    public function __construct($x = 0, $y = 0, $color = "black") {
        parent::__construct($x, $y);
        $this->color = $color;
        echo "ColorPoint created: ($this->x, $this->y), color: $this->color\n";
    }

    public function __destruct() {
        echo "ColorPoint destroyed: ($this->x, $this->y), color: $this->color\n";
        parent::__destruct();
    }

    public function printInfo() {
        echo "ColorPoint: ($this->x, $this->y), Color: $this->color\n";
    }
}

$p1 = new Point(3, 5);
$p1->printInfo();

$cp = new ColorPoint(10, 20, "red");
$cp->printInfo();

?>
