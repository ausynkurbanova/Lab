<?php

class Point {
    protected $x;
    protected $y;

    public static $count = 0;

    public function __construct($x = 0, $y = 0) {
        $this->x = $x;
        $this->y = $y;
        self::$count++;
    }

    public static function showCount() {
        echo "Кількість точок: " . self::$count . "\n";
    }
}

class ColorPoint extends Point {
    protected $color;

    public function __construct($x = 0, $y = 0, $color = "black") {
        parent::__construct($x, $y);
        $this->color = $color;
    }

    public static function classInfo() {
        echo "Це клас ColorPoint\n";
    }
}

$p1 = new Point(1, 2);
$p2 = new ColorPoint(3, 4, "red");

Point::showCount();
ColorPoint::classInfo();

?>
