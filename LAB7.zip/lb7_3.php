<?php

class Client
{
    public $name;
    public $address;
    public $accountNumber;
    public $mainBalance;   // основний рахунок
    public $creditBalance; // кредитний рахунок

    public function __construct($name, $address, $accountNumber, $mainBalance = 0, $creditBalance = 0)
    {
        $this->name = $name;
        $this->address = $address;
        $this->accountNumber = $accountNumber;
        $this->mainBalance = $mainBalance;
        $this->creditBalance = $creditBalance;
    }

    public function show()
    {
        echo "Ім'я: $this->name, Адреса: $this->address, Рахунок: $this->accountNumber\n";
        echo "Основний баланс: $this->mainBalance, Кредитний баланс: $this->creditBalance\n";
        echo "-------------------------\n";
    }
}

abstract class AbstractHandler
{
    protected $next;

    public function setNext($handler)
    {
        $this->next = $handler;
    }

    abstract public function handle($amount, Client $client);
}

class MainAccountHandler extends AbstractHandler
{
    public function handle($amount, Client $client)
    {
        if ($client->mainBalance >= $amount) {
            $client->mainBalance -= $amount;
            echo "Оплата $amount грн з основного рахунку клієнта {$client->name}. Залишок: {$client->mainBalance} грн\n";
        } elseif ($this->next) {
            $this->next->handle($amount, $client);
        } else {
            echo "Оплата відхилена для клієнта {$client->name}: недостатньо коштів.\n";
        }
    }
}

class CreditAccountHandler extends AbstractHandler
{
    public function handle($amount, Client $client)
    {
        if ($client->creditBalance >= $amount) {
            $client->creditBalance -= $amount;
            echo "Оплата $amount грн з кредитного рахунку клієнта {$client->name}. Залишок: {$client->creditBalance} грн\n";
        } elseif ($this->next) {
            $this->next->handle($amount, $client);
        } else {
            echo "Оплата відхилена для клієнта {$client->name}: недостатньо коштів.\n";
        }
    }
}


$client1 = new Client("Sofia", "Kyiv", "43893412", 1000, 500);
$client2 = new Client("Ivan", "Odesa", "56894574", 50, 200);
$client3 = new Client("Mila", "Lviv", "46907256", 0, 0);

$client1->show();
$client2->show();
$client3->show();

$mainHandler = new MainAccountHandler();
$creditHandler = new CreditAccountHandler();
$mainHandler->setNext($creditHandler);


$mainHandler->handle(300, $client1); // з основного рахунку
$mainHandler->handle(100, $client2); // з кредитного рахунку
$mainHandler->handle(50, $client3);  // недостатньо коштів


