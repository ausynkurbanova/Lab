<?php

abstract class AbstractHandler
{
    protected $_next;

    abstract public function handle($amount, $client);

    public function setNext($next)
    {
        $this->_next = $next;
    }

    public function getNext()
    {
        return $this->_next;
    }
}

class Client
{
    public $name;
    public $mainBalance;
    public $creditBalance;

    public function __construct($name, $mainBalance, $creditBalance)
    {
        $this->name = $name;
        $this->mainBalance = $mainBalance;
        $this->creditBalance = $creditBalance;
    }
}

class MainAccountHandler extends AbstractHandler
{
    public function handle($amount, $client)
    {
        if ($client->mainBalance >= $amount) {
            $client->mainBalance -= $amount;
            echo "Оплата $amount грн з основного рахунку клієнта {$client->name}. Залишок: {$client->mainBalance} грн\n";
        } elseif ($this->getNext()) {
            $this->getNext()->handle($amount, $client);
        } else {
            echo "Оплата відхилена: недостатньо коштів.\n";
        }
    }
}
class CreditAccountHandler extends AbstractHandler
{
    public function handle($amount, $client)
    {
        if ($client->creditBalance >= $amount) {
            $client->creditBalance -= $amount;
            echo "Оплата $amount грн з кредитного рахунку клієнта {$client->name}. Залишок: {$client->creditBalance} грн\n";
        } elseif ($this->getNext()) {
            $this->getNext()->handle($amount, $client);
        } else {
            echo "Оплата відхилена: недостатньо коштів.\n";
        }
    }
}

$client1 = new Client("Sofia", 1000, 500); // mainBalance = 1000, creditBalance = 500
$client2 = new Client("Ivan", 50, 200);    // mainBalance = 50, creditBalance = 200
$client3 = new Client("Mila", 0, 0);       // insufficient funds

$mainHandler = new MainAccountHandler();
$creditHandler = new CreditAccountHandler();

$mainHandler->setNext($creditHandler);

// Оплата покупки
$mainHandler->handle(300, $client1); // з основного рахунку
$mainHandler->handle(100, $client2); // з кредитного рахунку
$mainHandler->handle(50, $client3);  // недостатньо коштів

?>
